from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response

class StandardPagination(PageNumberPagination):
    page_size = 10
    page_size_query_param = "page_size"
    max_page_size = 100
    def get_paginated_response(self, data):
        return Response({
            "success": True,
            "message": "Data fetched",
            "error_code": None,
            "data": {
                "items": data,
                "pagination": {
                    "count": self.page.paginator.count,
                    "total_pages": self.page.paginator.num_pages,
                    "current_page": self.page.number,
                    "page_size": self.get_page_size(self.request),
                }
            }
        })

class RidePagination(StandardPagination):
    page_size = 20
