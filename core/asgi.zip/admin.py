from django.contrib import admin
from .models import Product

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'created_at']  # admin lo ee 3 columns chupistundi
    search_fields = ['name']
    list_filter = ['created_at']